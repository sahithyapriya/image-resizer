import os
from PIL import Image
from datetime import datetime

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
INPUT_FOLDER = os.path.join(BASE_DIR, "input_images")
OUTPUT_FOLDER = os.path.join(BASE_DIR, "output_images")
LOG_FILE = os.path.join(BASE_DIR, "process_log.txt")

TARGET_SIZE = (800, 600)  
OUTPUT_FORMAT = "JPEG"

def log(message):
    time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with open(LOG_FILE, "a", encoding="utf-8") as f:
        f.write(f"[{time}] {message}\n")

def resize_force(img, target_size):
    return img.resize(target_size, Image.Resampling.LANCZOS)

def process_images():
    if not os.path.exists(OUTPUT_FOLDER):
        os.makedirs(OUTPUT_FOLDER)
    files = os.listdir(INPUT_FOLDER)
    images = [f for f in files if f.lower().endswith(('.png', '.jpg', '.jpeg', '.webp'))]
    print(f"Found {len(images)} image(s) to process.")

    for file in images:
        try:
            input_path = os.path.join(INPUT_FOLDER, file)
            output_name = f"resized_{os.path.splitext(file)[0]}.jpg"
            output_path = os.path.join(OUTPUT_FOLDER, output_name)

            with Image.open(input_path) as img:
                img = img.convert("RGB")  
                resized_img = resize_force(img, TARGET_SIZE)
                resized_img.save(output_path, OUTPUT_FORMAT)
                print(f"✔ Processed: {file} → {output_name}")
                log(f"Processed: {file} → {output_name}")
        except Exception as e:
            error_message = f"Failed to process {file}: {e}"
            print(error_message)
            log(error_message)

if __name__ == "__main__":
    process_images()
